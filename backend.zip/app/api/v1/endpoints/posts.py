from fastapi import APIRouter, Depends
from app.core.deps import get_cursor, get_current_user_id
from app.schemas.post import PostCreate
from app.crud import post as post_crud

router = APIRouter()

@router.get("/")
def get_posts(cursor=Depends(get_cursor)):
    # Returns the list of dicts directly from CRUD
    return post_crud.get_feed(cursor)

@router.post("/")
def create_post(post: PostCreate, user_id: str = Depends(get_current_user_id), cursor=Depends(get_cursor)):
    pid = post_crud.create_post(cursor, user_id, post.content, post.image)
    return {"success": True, "id": pid}

@router.post("/{post_id}/like")
def like_post(post_id: str, user_id: str = Depends(get_current_user_id), cursor=Depends(get_cursor)):
    liked = post_crud.toggle_like(cursor, user_id, post_id)
    return {"success": True, "liked": liked}